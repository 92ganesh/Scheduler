package edu.somaiya.app.scheduler2.admin;

import android.graphics.Point;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import edu.somaiya.app.scheduler2.GlobalVariables;
import edu.somaiya.app.scheduler2.R;

public class AdminGrid extends AppCompatActivity {

    public int gridWidth=-10,gridHeigth=-10,rows,cols;
    HashMap<String,Object> formDetails;
    HashMap<String,String> memberActivityMap;
    TreeMap<String,String> memberActivityMapSorted;
    String rowNames="", colNames="", csvString="", groupLabelNames="", formName="";
    public DatabaseReference myRef;
    boolean isFirebaseConnected=false;
    String[][] gridMat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_grid);

        // get window size
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        gridWidth=size.x;
        gridHeigth=size.y;


        // get firebase instance
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference().child(GlobalVariables.typeForm);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                // String value = dataSnapshot.getValue(String.class);
                Iterable<DataSnapshot> contactChildren = dataSnapshot.getChildren();
                for (DataSnapshot contact : contactChildren) {
                    String formId= contact.getKey();
                    if(formId.equals(GlobalVariables.currForm)){
                        rows = Integer.parseInt((String)contact.child("totalRows").getValue() );
                        cols = Integer.parseInt((String)contact.child("totalCols").getValue() );
                        formDetails = (HashMap)contact.child("formTableDetails").getValue();
                        rowNames = (String)contact.child("rowNames").getValue();
                        colNames = (String)contact.child("colNames").getValue();
                        groupLabelNames = (String)contact.child("groupLabelNames").getValue();
                        formName = (String)contact.child("name").getValue();
                        memberActivityMap = (HashMap<String, String>) contact.child("memberActivity").getValue();
                        if(memberActivityMap!=null) {
                            gridMat = new String[memberActivityMap.size()+3][rows+1];
                        }else{
                            gridMat = new String[3][rows+1];
                        }
                        makeGrid();
                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(getApplicationContext(),"cannot connect to database",Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void makeGrid(){
        String[] rn = rowNames.split("!");
        String[] cn = colNames.split("!");
        String[] gn = groupLabelNames.split("!");
        int gridCols = rows;

        for(int i=0;i<gridMat.length;i++){
            for(int j=0;j<gridMat[i].length;j++){
                addButton(i,j,"",false);
                gridMat[i][j] = "";
            }
        }

        addButton(0,0,"",true);

        // rows contains num of slots
        // Note:- slot are represented as columns here.
        for(int i=1; i<=gridCols; i++){
            addButton(0,i,gn[i-1],true);
            addButton(1,i,rn[i-1],true);
            gridMat[0][i] = gn[i-1];
            gridMat[1][i] = rn[i-1];
        }

        int i=2;
        if(memberActivityMap!=null){
            memberActivityMapSorted=new TreeMap<>();
            for(Map.Entry<String,String> entry: memberActivityMap.entrySet()) {
                memberActivityMapSorted.put(entry.getKey(),entry.getValue());
            }
            for(Map.Entry<String,String> entry: memberActivityMapSorted.entrySet()){
                addButton(i,0,entry.getKey(),true);
                gridMat[i][0] = entry.getKey();
                String[] userSelection = entry.getValue().split("!");
                for(String each:userSelection){
                    int colNum = Integer.parseInt( (each.split(","))[0]);
                    addButton(i,colNum,"X",false);
                    gridMat[i][colNum] = "X";
                }
                i++;
            }
        }

        addButton(i,0,"Total",true);
        gridMat[i][0] = "Total";
        for(int j=1; j<=gridCols; j++){
            int xCount=0;
            for(int k=2; k<i; k++) {
                if(gridMat[k][j].equals("X")){
                    xCount++;
                }
            }
            gridMat[i][j] = xCount+"";
            addButton(i,j,xCount+"",false);
        }
    }

    public void addButton(int r, int c,String owner,boolean NamePlates){
        GridLayout gd = findViewById(R.id.userTableGrid);
        TextView txt = new TextView(this);
        txt.setWidth(gridWidth/6);
        txt.setHeight(gridHeigth/15);

        txt.setTextSize(20);
        txt.setPadding(0,10,0,10);
        txt.setBackground(getResources().getDrawable(R.drawable.border));
        txt.setId( ((r-1)*cols) + (c-1) +1 );


        if(!NamePlates) {
            if (owner.equals("free")) {
                txt.setTextColor(getResources().getColor(R.color.colorFree));
            } else {
                txt.setTextColor(getResources().getColor(R.color.colorAssigned));
            }
            txt.setGravity(Gravity.CENTER_HORIZONTAL);
        }else{
            txt.setTextColor(getResources().getColor(R.color.colorGridlabels));
        }
        txt.setText(owner);
        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        param.width = GridLayout.LayoutParams.WRAP_CONTENT;
        param.columnSpec = GridLayout.spec(c);
        param.rowSpec = GridLayout.spec(r);
        txt.setLayoutParams(param);
        gd.addView(txt);
    }

    public void saveToCSV(View view){
        csvString="";
        for(int i=0;i<gridMat.length;i++){
            for(int j=0;j<gridMat[i].length;j++){
                csvString+=gridMat[i][j];
                if(i<gridMat[i].length){ csvString+=" ,";}
            }
            csvString+="\n";
        }

        Log.e("csv",csvString);
        String sdcardFolder = Environment.getExternalStorageDirectory().getAbsolutePath()+"/formName.csv";
        FileWriter sb = null;
        try {
            sb = new FileWriter(sdcardFolder);
            sb.append(csvString);
            sb.close();
            Toast.makeText(getApplicationContext(),"saved to disk",Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e("AdminGrid.java",e.toString());
            Toast.makeText(getApplicationContext(),"failed to save",Toast.LENGTH_LONG).show();
        }
    }

}
