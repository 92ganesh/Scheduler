package edu.somaiya.app.scheduler2.admin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import edu.somaiya.app.scheduler2.R;

public class RemoveAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_admin);
    }
}
