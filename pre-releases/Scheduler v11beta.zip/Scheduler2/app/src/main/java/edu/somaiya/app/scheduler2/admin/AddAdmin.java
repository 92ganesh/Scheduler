package edu.somaiya.app.scheduler2.admin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import edu.somaiya.app.scheduler2.R;

public class AddAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_admin);
    }

    public void addAdmin(View view){
      //  EditText ed = ed
    }
}
