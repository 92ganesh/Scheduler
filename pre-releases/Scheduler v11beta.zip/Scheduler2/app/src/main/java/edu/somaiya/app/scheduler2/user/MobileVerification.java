package edu.somaiya.app.scheduler2.user;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import edu.somaiya.app.scheduler2.R;

public class MobileVerification extends AppCompatActivity {
    private String TAG = "MainActivity",mobileVerificationPurpose="";
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private String verId="";
    private long timeout=30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_verification);

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            return;
        }
        mobileVerificationPurpose = extras.getString("mobileVerificationPurpose");
    }

//    private void addLog(String msg){
//        TextView tx = findViewById(R.id.logs);
//        String s = tx.getText().toString();
//        tx.setText(s+"\n*"+msg);
//    }

    public void enterOTP(View view){
        EditText ed = findViewById(R.id.mobile);
        String phoneNum = ed.getText().toString();

        if(phoneNum!=""){
            phoneNum="+91"+phoneNum;
            Intent i = new Intent(getApplicationContext(), VerifyOTP.class);
            i.putExtra("mobile",phoneNum);
            i.putExtra("mobileVerificationPurpose",mobileVerificationPurpose);
            startActivity(i);
        }
    }
}
