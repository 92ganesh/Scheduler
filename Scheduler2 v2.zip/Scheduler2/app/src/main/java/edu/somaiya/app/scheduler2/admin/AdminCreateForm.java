package edu.somaiya.app.scheduler2.admin;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import edu.somaiya.app.scheduler2.R;

public class AdminCreateForm extends AppCompatActivity {
    public DatabaseReference myRef;
    public static ArrayList<Integer> rowIDs=new ArrayList<>();
    public static ArrayList<Integer> colIDs=new ArrayList<>();
    public static int rowCount=0, colCount=0, idCount=0, gridWidth=-10,gridHeigth=-10;
    private int GRID_TEXT_COLOR;

    //form attributes
    String formId,formName,rowNames,colNames,formDue,totalRows,totalCols;
    public static Map<String, Object> formTableDetails, form;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_create_form);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference();


        myRef.child("globalData").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> contactChildren = dataSnapshot.getChildren();
                for (DataSnapshot contact : contactChildren) {
                    if(contact.getKey().equals("totalForms")){
                        String formIdStr =  (String)contact.getValue();
                        if(formIdStr.equals(formId))
                            Toast.makeText(getApplicationContext(),"FORM CREATED",Toast.LENGTH_LONG).show();

                        int formIdint =Integer.parseInt(formIdStr)+1;
                        formId = formIdint+"";
                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(getApplicationContext(),"cannot connect to database",Toast.LENGTH_LONG).show();
            }
        });



        GRID_TEXT_COLOR = getResources().getColor(R.color.colorAssigned);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        gridWidth=size.x;
        gridHeigth=size.y;

        addRow();
        addCol();

        EditText fn = findViewById(R.id.formName);
        fn.setWidth(gridWidth/2);

        EditText fd = findViewById(R.id.formDue);
        fd.setWidth(gridWidth/2);

    }

    public void createForm(View view){
        EditText ed = findViewById(R.id.formName);
        formName = ed.getText().toString();

        rowNames="";
        for(int i=0; i<rowIDs.size(); i++){
            ed = findViewById(rowIDs.get(i));
            rowNames += ed.getText().toString();
            if(i!=rowIDs.size()-1)
                rowNames+="!";
        }

        colNames="";
        for(int i=0; i<colIDs.size(); i++){
            ed = findViewById(colIDs.get(i));
            colNames += ed.getText().toString();
            if(i!=colIDs.size()-1)
                colNames+="!";
        }

        ed = findViewById(R.id.formDue);
        formDue = ed.getText().toString();

        totalRows=rowCount+"";
        totalCols=colCount+"";

        formTableDetails=new HashMap<>();
        for(int i=1;i<=rowCount;i++){
            for(int j=1;j<=colCount;j++){
                formTableDetails.put(i+","+j,"free");
            }
        }

        // add all form components
        form = new HashMap<>();
        form.put("name",formName);
        form.put("due",formDue);
        form.put("rowNames",rowNames);
        form.put("colNames",colNames);
        form.put("totalRows",totalRows);
        form.put("totalCols",totalCols);
        form.put("formTableDetails",formTableDetails);

        myRef.child("formLive").child(formId).setValue(form);
        myRef.child("globalData").child("totalForms").setValue(formId);
    }



    public void rPlus(View view){
        addRow();
    }
    public void cPlus(View view){
        addCol();
    }

    public void rMinus(View view){
        subRow();
    }
    public void cMinus(View view){
        subCol();
    }


    public void subRow(){
        GridLayout gd = findViewById(R.id.createTableGrid);
        if(gd.getRowCount()>2) {
            rowCount--;
            View re = findViewById(rowIDs.get(rowIDs.size() - 1));
            gd.removeView(re);
            rowIDs.remove(rowIDs.size() - 1);
        }
    }

    public void subCol(){
        GridLayout gd = findViewById(R.id.createTableGrid);
        if(gd.getColumnCount()>2) {
            colCount--;
            View re = findViewById(colIDs.get(colIDs.size() - 1));
            gd.removeView(re);
            colIDs.remove(colIDs.size() - 1);
        }
    }


    public void addRow(){
        idCount++; rowCount++;
        GridLayout gd = findViewById(R.id.createTableGrid);
        EditText txt = new EditText(this);
        txt.setWidth(gridWidth/6);
        txt.setTextSize(20);
        txt.setPadding(0,10,0,10);
        txt.setBackground(getResources().getDrawable(R.drawable.border));
        txt.setId(idCount);
        rowIDs.add(idCount);
        txt.setText("R"+rowCount);
        txt.setTextColor(GRID_TEXT_COLOR);

        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        param.width = GridLayout.LayoutParams.WRAP_CONTENT;
        param.columnSpec = GridLayout.spec(0);
        param.rowSpec = GridLayout.spec(rowCount);
        txt.setLayoutParams(param);
        gd.addView(txt);
    }

    public void addCol(){
        idCount++; colCount++;
        GridLayout gd = findViewById(R.id.createTableGrid);
        EditText txt = new EditText(this);
        txt.setWidth(gridWidth/6);
        txt.setTextSize(20);
        txt.setPadding(0,10,0,10);
        txt.setBackground(getResources().getDrawable(R.drawable.border));
        txt.setId(idCount);
        colIDs.add(idCount);
        txt.setText("C"+colCount);
        txt.setTextColor(GRID_TEXT_COLOR);

        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        param.width = GridLayout.LayoutParams.WRAP_CONTENT;
        param.columnSpec = GridLayout.spec(colCount);
        param.rowSpec = GridLayout.spec(0);
        txt.setLayoutParams(param);
        gd.addView(txt);
    }
}
