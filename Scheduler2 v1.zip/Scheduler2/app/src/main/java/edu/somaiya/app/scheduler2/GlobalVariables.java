package edu.somaiya.app.scheduler2;

/**
 * Created by Patra's Home on 10-01-2019.
 */

public class GlobalVariables {
    public static String currForm="1";
    public static String typeForm="formPast";
    public static String currUser="AES";
    public static int minSelection=3;

}
