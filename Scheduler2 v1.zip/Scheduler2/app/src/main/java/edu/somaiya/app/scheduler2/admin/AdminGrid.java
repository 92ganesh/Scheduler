package edu.somaiya.app.scheduler2.admin;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

import edu.somaiya.app.scheduler2.GlobalVariables;
import edu.somaiya.app.scheduler2.R;

public class AdminGrid extends AppCompatActivity {
    public int gridWidth=-10,gridHeigth=-10,rows,cols;
    Map<String,Object> formDetails;
    String rowNames="", colNames="";
    public DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_grid);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        gridWidth=size.x;
        gridHeigth=size.y;
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference().child(GlobalVariables.typeForm);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                // String value = dataSnapshot.getValue(String.class);
                Iterable<DataSnapshot> contactChildren = dataSnapshot.getChildren();
                for (DataSnapshot contact : contactChildren) {
                    String formId= contact.getKey();
                    if(formId.equals(GlobalVariables.currForm)){
                        rows = Integer.parseInt((String)contact.child("totalRows").getValue() );
                        cols = Integer.parseInt((String)contact.child("totalCols").getValue() );
                        formDetails = (HashMap)contact.child("formTableDetails").getValue();
                        rowNames = (String)contact.child("rowNames").getValue();
                        colNames = (String)contact.child("colNames").getValue();
                        makeGrid();
                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(getApplicationContext(),"cannot connect to database",Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void makeGrid(){
        String[] rn = rowNames.split("!");
        String[] cn = colNames.split("!");

        addButton(0,0,"",true);

        for(int i=1; i<=cols; i++){
            addButton(0,i,cn[i-1],true);
        }
        for(int i=1; i<=rows; i++){
            addButton(i,0,rn[i-1],true);
        }

        for(int i=1; i<=rows; i++){
            for(int j=1; j<=cols; j++){
                String loc = i+","+j;
                addButton(i,j,(String)formDetails.get(loc), false);
            }
        }

    }

    public void addButton(int r, int c,String owner,boolean NamePlates){
        GridLayout gd = findViewById(R.id.userTableGrid);
        TextView txt = new TextView(this);
        txt.setWidth(gridWidth/(cols+1));
        txt.setTextSize(20);
        txt.setPadding(0,10,0,10);
        txt.setBackground(getResources().getDrawable(R.drawable.border));
        txt.setId( ((r-1)*rows) + (c-1) );

        if(!NamePlates) {
            if (owner.equals("free")) {
                txt.setTextColor(getResources().getColor(R.color.colorFree));
            } else {
                txt.setTextColor(getResources().getColor(R.color.colorAssigned));
            }
        }else{
            txt.setTextColor(getResources().getColor(R.color.colorGridlabels));

        }
        txt.setText(owner);
        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        param.width = GridLayout.LayoutParams.WRAP_CONTENT;
        param.columnSpec = GridLayout.spec(c);
        param.rowSpec = GridLayout.spec(r);
        txt.setLayoutParams(param);
        gd.addView(txt);
    }

}
