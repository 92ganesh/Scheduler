package edu.somaiya.app.scheduler2.user;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import edu.somaiya.app.scheduler2.R;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


    }
}
