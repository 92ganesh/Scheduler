package edu.somaiya.app.scheduler2;

/**
 * Created by Patra's Home on 10-01-2019.
 */

public class GlobalVariables {
    public static String currForm="2";
    public static String typeForm="formLive";
    public static String currUser="dummyUser";
    public static int minSelection=3;

}
