package edu.somaiya.app.scheduler2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import edu.somaiya.app.scheduler2.admin.AdminCreateForm;
import edu.somaiya.app.scheduler2.admin.AdminGrid;
import edu.somaiya.app.scheduler2.admin.AdminMain;
import edu.somaiya.app.scheduler2.user.UserForms;
import edu.somaiya.app.scheduler2.user.UserGrid;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void launchAdmin(View view){
        GlobalVariables.currUser = "admin";
        Intent i = new Intent(getApplicationContext(), AdminMain.class);
        startActivity(i);
    }

    public void launchUser(View view){
        EditText ed = findViewById(R.id.ed);
        String userName = ed.getText().toString();
        if(!userName.equals("")) {
            GlobalVariables.currUser = userName;
        }
        Intent i = new Intent(getApplicationContext(), UserForms.class);
        startActivity(i);
    }
}
