package edu.somaiya.app.schedulertestdb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public DatabaseReference myRef;
    public static int totalForms, totalMembers,totalMembersForApproval;
    public static Map<String, String> memberDetails,formTableDetails,formTableDetailsLab,memberActivity ;
    public static Map<String, Object> formLive,formPast,formDetails,everything;
    public static Map<String, String> globalData=new HashMap<>();
    public static Map<String, Object> membersList=new HashMap<>();
    public static Map<String, Object> membersForApproval=new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        JSONObject obj = new JSONObject();
//
//        try {
//
//            obj.put("name", "foo");
//            obj.put("num", new Integer(100));
//            obj.put("balance", new Double(1000.21));
//            obj.put("is_vip", new Boolean(true));
//
//            AssetFileDescriptor fileDescriptor = this.getAssets().openFd("testDB.json");
//            FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
//
//            String jsonString = obj.toString();
//            Map<String, Object> retMap = new Gson().fromJson(
//                    jsonString, new TypeToken<HashMap<String, Object>>() {}.getType()
//            );
//
//            // Write a message to the database
//            FirebaseDatabase database = FirebaseDatabase.getInstance();
//            myRef = database.getReference();
//            myRef.setValue(retMap);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
    }

    @Override
    protected void onResume() {
        super.onResume();
        totalForms=0; totalMembers=0; totalMembersForApproval=0;
        addMembers();   addforms(); addMembersForApproval();

        globalData.put("totalForms",totalForms+"");
        globalData.put("totalMembers",totalMembers+"");
        globalData.put("totalMembersForApproval",totalMembersForApproval+"");

        everything =new HashMap<>();
        everything.put("globalData",globalData);
        everything.put("membersList",membersList);
        everything.put("membersForApproval",membersForApproval);
        everything.put("formLive",formLive);
        everything.put("formPast",formPast);
        myRef.setValue(everything);
    }

    private static void addforms() {
        // past forms
        int formId = ++totalForms; int tc=1,tr=9;
        formDetails = new HashMap<>();
        formDetails.put("name","sem 5");
        formDetails.put("due","15/11/18");
        formDetails.put("totalRows",tr+"");
        formDetails.put("totalCols","2");
//        formDetails.put("maxInRow","3");
//        formDetails.put("maxInCol","3");
        formDetails.put("totalSelectionProfessor","2");
        formDetails.put("totalSelectionAssociate","3");
        formDetails.put("totalSelectionAssistant","4");
        formDetails.put("totalSelectionLabAssistant","5");
        formDetails.put("rowNames","R1!R2!R3!R4!R5!R6!R7!R8!R9");
        formDetails.put("colNames","Day!Slot!Limit");
        formDetails.put("groupLabelNames","Day 1!Day 1!Day 1!Day 2!Day 2!Day 2!Day 3!Day 3!Day 3");

        formTableDetails=new HashMap<>();
        formTableDetails.put(1+","+1,"4");
        formTableDetails.put(2+","+1,"2");
        formTableDetails.put(3+","+1,"2");
        formTableDetails.put(4+","+1,"4");
        formTableDetails.put(5+","+1,"4");
        formTableDetails.put(6+","+1,"2");
        formTableDetails.put(7+","+1,"2");
        formTableDetails.put(8+","+1,"2");
        formTableDetails.put(9+","+1,"2");

        formTableDetailsLab=new HashMap<>();
        formTableDetailsLab.put(1+","+1,"2");
        formTableDetailsLab.put(2+","+1,"1");
        formTableDetailsLab.put(3+","+1,"1");
        formTableDetailsLab.put(4+","+1,"2");
        formTableDetailsLab.put(5+","+1,"2");
        formTableDetailsLab.put(6+","+1,"1");
        formTableDetailsLab.put(7+","+1,"1");
        formTableDetailsLab.put(8+","+1,"1");
        formTableDetailsLab.put(9+","+1,"1");

        memberActivity = new HashMap<>();
        memberActivity.put("PRO","2,1!4,1");
       // memberActivity.put("ASO","2,1!3,1!6,1");
        memberActivity.put("ASI","1,1!4,1!5,1!6,1");
        memberActivity.put("LAB","1,1!3,1!4,1!5,1!6,1");

        formDetails.put("formTableDetails",formTableDetails);
        formDetails.put("formTableDetailsLab",formTableDetailsLab);
        formDetails.put("memberActivity",memberActivity);
        formPast = new HashMap<>();
        formPast.put(formId+"",formDetails);

        // live forms
        formId = ++totalForms; tc=1; tr=9;
        formDetails = new HashMap<>();
        formDetails.put("name","unit test 1");
        formDetails.put("due","20/02/19");
        formDetails.put("totalRows",tr+"");
        formDetails.put("totalCols","2");
//        formDetails.put("maxInRow","3");
//        formDetails.put("maxInCol","3");
        formDetails.put("totalSelectionProfessor","2");
        formDetails.put("totalSelectionAssociate","3");
        formDetails.put("totalSelectionAssistant","4");
        formDetails.put("totalSelectionLabAssistant","5");
        formDetails.put("rowNames","R1!R2!R3!R4!R5!R6!R7!R8!R9");
        formDetails.put("colNames","Day!Slot!Limit");
        formDetails.put("groupLabelNames","Day 1!Day 1!Day 1!Day 2!Day 2!Day 2!Day 3!Day 3!Day 3");

        formTableDetails=new HashMap<>();
        formTableDetailsLab=new HashMap<>();
        for(int i=1;i<=tr;i++){
            for(int j=1;j<=tc;j++){
                formTableDetails.put(i+","+j,"4");
                formTableDetailsLab.put(i+","+j,"2");
            }
        }
        formDetails.put("formTableDetails",formTableDetails);
        formDetails.put("formTableDetailsLab",formTableDetailsLab);
        formLive = new HashMap<>();
        formLive.put(formId+"",formDetails);

    }

    private static void addMembers(){
        memberDetails=new HashMap<>();
        memberDetails.put("code","PRO");
        memberDetails.put("name","PRO_name");
        memberDetails.put("email","PRO_email");
        memberDetails.put("mobile","+919999999999");
        memberDetails.put("designation","professor");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","ASO");
        memberDetails.put("name","ASO_name");
        memberDetails.put("email","ASO_email");
        memberDetails.put("mobile","+919999999998");
        memberDetails.put("designation","associate");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","ASI");
        memberDetails.put("name","ASI_name");
        memberDetails.put("email","ASI_email");
        memberDetails.put("mobile","NA");
        memberDetails.put("designation","assitant");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","LAB");
        memberDetails.put("name","LAB_name");
        memberDetails.put("email","LAB_email");
        memberDetails.put("mobile","NA");
        memberDetails.put("designation","labAssitant");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","GAN");
        memberDetails.put("name","Ganesh");
        memberDetails.put("email","tp92ganeshpatra@gmail.com");
        memberDetails.put("mobile","+919619758732");
        memberDetails.put("designation","admin");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;
    }

    private static void addMembersForApproval() {
        memberDetails = new HashMap<>();
        memberDetails.put("code", "AAL");
        memberDetails.put("name", "AAL_name");
        memberDetails.put("email", "AAL_email");
        memberDetails.put("mobile", "+919999999997");
        memberDetails.put("designation","associate");
        membersForApproval.put(memberDetails.get("code"), memberDetails);
        totalMembersForApproval++;

        memberDetails = new HashMap<>();
        memberDetails.put("code", "TUI");
        memberDetails.put("name", "TUI_name");
        memberDetails.put("email", "TUI_email");
        memberDetails.put("mobile", "NA");
        memberDetails.put("designation","labAssitant");
        membersForApproval.put(memberDetails.get("code"), memberDetails);
        totalMembersForApproval++;
    }


    }
