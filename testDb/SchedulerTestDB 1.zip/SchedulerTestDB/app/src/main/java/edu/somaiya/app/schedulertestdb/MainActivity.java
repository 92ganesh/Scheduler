package edu.somaiya.app.schedulertestdb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public DatabaseReference myRef;
    public static int totalForms, totalMembers,totalMembersForApproval;
    public static Map<String, Object> dbStrudture=new HashMap<>();
    public static Map<String, String> globalData=new HashMap<>();
    public static Map<String, Object> membersList=new HashMap<>();
    public static Map<String, Object> membersForApproval=new HashMap<>();
    public static Map<String, String> memberDetails;
    public static Map<String, Object> formLive;
    public static Map<String, Object> formPast;
    public static Map<String, Object> formDetails;
    public static Map<String, String> formTableDetails;
    public static Map<String, Object> everthing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
    }

    @Override
    protected void onResume() {
        super.onResume();

        totalForms=0; totalMembers=0; totalMembersForApproval=0;

        addMembers();   addforms(); addMembersForApproval();

        globalData.put("totalForms",totalForms+"");
        globalData.put("totalMembers",totalMembers+"");
        globalData.put("totalMembersForApproval",totalMembersForApproval+"");

        everthing=new HashMap<>();
        everthing.put("globalData",globalData);
        everthing.put("membersList",membersList);
        everthing.put("membersForApproval",membersForApproval);
        everthing.put("formLive",formLive);
        everthing.put("formPast",formPast);
        myRef.setValue(everthing);

//        myRef.child("globalData").setValue(globalData);
//        myRef.child("membersList").setValue(membersList);
//        myRef.child("membersForApproval").setValue(membersForApproval);
//
//        // forms
//        myRef.child("formLive").setValue(formLive);
//        myRef.child("formPast").setValue(formPast);
    }

    private static void addforms() {
        // past forms
        int formId = ++totalForms; int tc=3,tr=3;
        formDetails = new HashMap<>();
        formDetails.put("name","sem 5");
        formDetails.put("due","15/11/18");
        formDetails.put("totalRows","3");
        formDetails.put("totalCols","3");
        formDetails.put("maxInRow","3");
        formDetails.put("maxInCol","3");
        formDetails.put("totalSelection","5");
        formDetails.put("rowNames","R1!R2!R3");
        formDetails.put("colNames","C1!C2!C3");

        formTableDetails=new HashMap<>();
        formTableDetails.put(2+","+1,"free"); formTableDetails.put(3+","+2,"free"); formTableDetails.put(1+","+3,"free");
        formTableDetails.put(1+","+1,"AES"); formTableDetails.put(2+","+3,"AES");
        formTableDetails.put(3+","+1,"SSL");  formTableDetails.put(2+","+2,"SSL");
        formTableDetails.put(1+","+2,"SHA");  formTableDetails.put(3+","+3,"SHA");

        formDetails.put("formTableDetails",formTableDetails);
        formPast = new HashMap<>();
        formPast.put(formId+"",formDetails);


        // live forms
        formId = ++totalForms; tc=3; tr=3;
        formDetails = new HashMap<>();
        formDetails.put("name","unit test 1");
        formDetails.put("due","20/02/19");
        formDetails.put("totalRows","3");
        formDetails.put("totalCols","3");
        formDetails.put("maxInRow","3");
        formDetails.put("maxInCol","3");
        formDetails.put("totalSelection","5");
        formDetails.put("rowNames","R1!R2!R3");
        formDetails.put("colNames","C1!C2!C3");

        formTableDetails=new HashMap<>();
        for(int i=1;i<=tr;i++){
            for(int j=1;j<=tc;j++){
                formTableDetails.put(i+","+j,"free");
            }
        }
        formDetails.put("formTableDetails",formTableDetails);
        formLive = new HashMap<>();
        formLive.put(formId+"",formDetails);

    }

    private static void addMembers(){
        memberDetails=new HashMap<>();
        memberDetails.put("code","AES");
        memberDetails.put("name","AES_name");
        memberDetails.put("email","AES_email");
        memberDetails.put("mobile","9876543210");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","SSL");
        memberDetails.put("name","SSL_name");
        memberDetails.put("email","SSL_email");
        memberDetails.put("mobile","8876543210");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;

        memberDetails=new HashMap<>();
        memberDetails.put("code","SHA");
        memberDetails.put("name","SHA_name");
        memberDetails.put("email","SHA_email");
        memberDetails.put("mobile","NA");
        membersList.put( memberDetails.get("code"),memberDetails );
        totalMembers++;
    }

    private static void addMembersForApproval() {
        memberDetails = new HashMap<>();
        memberDetails.put("code", "AAL");
        memberDetails.put("name", "AAL_name");
        memberDetails.put("email", "AAL_email");
        memberDetails.put("mobile", "9876543210");
        membersForApproval.put(memberDetails.get("code"), memberDetails);
        totalMembersForApproval++;

        memberDetails = new HashMap<>();
        memberDetails.put("code", "TUI");
        memberDetails.put("name", "TUI_name");
        memberDetails.put("email", "TUI_email");
        memberDetails.put("mobile", "NA");
        membersForApproval.put(memberDetails.get("code"), memberDetails);
        totalMembersForApproval++;
    }


    }
